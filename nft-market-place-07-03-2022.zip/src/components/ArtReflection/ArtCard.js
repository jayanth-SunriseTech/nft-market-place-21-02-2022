import React from 'react';


function ArtCard() {
  return (
    <div>
        <div className="card" style="width: 18rem;">
  <img className="card-img-top" src={} alt="Card image cap"/>
  <div className="card-body">
  <img src='' />
    <h5 className="card-title artTitle">Card title</h5>
    <span className='userNAme'></span>
    
  </div>
</div>
    </div>
  )
}

export default ArtCard