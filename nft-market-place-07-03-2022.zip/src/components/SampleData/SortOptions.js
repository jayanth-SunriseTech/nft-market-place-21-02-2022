let SortOptions = [ 
    {
        heading:'Sort by',
        id:'flush-headingOne',
        collapseId:'flush-collapseOne',
        collapseTarget:'#flush-collapseOne',
        SortOption1:'Recently Listed',
        SortOption2:'Ending Soon',
        SortOption3:'Price Low to High',
        SortOption4:'Price High to Low',
        SortOption5:'Most Favourited',
    },
    
    
]

export default SortOptions