const CurrenciesOptions = [
    { key: 'USD', text: 'United States Dollar (USD)', value: 'USD' },
    { key: 'INR', text: 'Indian Rupee', value: 'INR' },
    { key: 'AUD', text: 'Australian Dollar', value: 'AUD' },
    { key: 'EUR', text: 'Euro', value: 'EUR' },
  ]

  export default CurrenciesOptions