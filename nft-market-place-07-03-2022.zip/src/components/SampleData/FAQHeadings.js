let FAQHeadings = [ 
    {
        heading:'Who is Indigena ?',
        id:'flush-headingOne',
        collapseId:'flush-collapseOne',
        collapseTarget:'#flush-collapseOne',
        answer:'Indigena is a group comprised of distinctive Indigenous backgrounds from across the globe coming together as one.Made by indigenous for indigenous people.'
    },
    {
        heading:'What is Indigena ?',
        id:'flush-headingTwo',
        collapseId:'flush-collapseTwo',
        collapseTarget:'#flush-collapseTwo',
        answer:'A community/ eco-system for indigenous people with true ownership of your own content and governance power over INDI ECOSystem with INDI Token  Indigena is an ecosystem that we can use to thrive on the blockchain. It is important to understand the difference between INDI and Indigena,Indi is the governance token of the Indigena eco-system.  Indigena was created to encourage positive changes and democratize Cultural preservation.'
    },
    {
        heading:'Solution We provide',
        id:'flush-headingThree',
        collapseId:'flush-collapseThree',
        collapseTarget:'#flush-collapseThree',
        answer:'Indigena is a group comprised of distinctive Indigenous backgrounds from across the globe coming together as one.Made by indigenous for indigenous people.'
    },
    {
        heading:'Is Indigena linked with Ripple or Flare Network ?',
        id:'flush-headingFour',
        collapseId:'flush-collapseFour',
        collapseTarget:'#flush-collapseFour',
        answer:'Indigena is a group comprised of distinctive Indigenous backgrounds from across the globe coming together as one.Made by indigenous for indigenous people.'
    },
    {
        heading:'What make us Unique ?',
        id:'flush-headingFive',
        collapseId:'flush-collapseFive',
        collapseTarget:'#flush-collapseFive',
        answer:'Indigena is a group comprised of distinctive Indigenous backgrounds from across the globe coming together as one.Made by indigenous for indigenous people.'
    },
    {
        heading:'Language Barrier',
        id:'flush-headingSix',
        collapseId:'flush-collapseSix',
        collapseTarget:'#flush-collapseSix',
        answer:'Indigena is a group comprised of distinctive Indigenous backgrounds from across the globe coming together as one.Made by indigenous for indigenous people.'
    },
    {
        heading:'Fees',
        id:'flush-headingSeven',
        collapseId:'flush-collapseSeven',
        collapseTarget:'#flush-collapseSeven',
        answer:'Indigena is a group comprised of distinctive Indigenous backgrounds from across the globe coming together as one.Made by indigenous for indigenous people.'
    },
    {
        heading:'Where Can we buy INDI ?',
        id:'flush-headingEight',
        collapseId:'flush-collapseEight',
        collapseTarget:'#flush-collapseEight',
        answer:'Indigena is a group comprised of distinctive Indigenous backgrounds from across the globe coming together as one.Made by indigenous for indigenous people.'
    },
    {
        heading:'Future Operations',
        id:'flush-headingNine',
        collapseId:'flush-collapseNine',
        collapseTarget:'#flush-collapseNine',
        answer:'Indigena is a group comprised of distinctive Indigenous backgrounds from across the globe coming together as one.Made by indigenous for indigenous people.'
    },
    {
        heading:'What is INDI Labs ?',
        id:'flush-headingTen',
        collapseId:'flush-collapseOne',
        collapseTarget:'#flush-collapseOne',
        answer:'Indigena is a group comprised of distinctive Indigenous backgrounds from across the globe coming together as one.Made by indigenous for indigenous people.'
    },
    {
        heading:'INDI Labs Developers program',
        id:'flush-headingEleven',
        collapseId:'flush-collapseEleven',
        collapseTarget:'#flush-collapseEleven',
        answer:'Indigena is a group comprised of distinctive Indigenous backgrounds from across the globe coming together as one.Made by indigenous for indigenous people.'
    },
    {
        heading:'Contact us',
        id:'flush-headingTwelve',
        collapseId:'flush-collapseTwelve',
        collapseTarget:'#flush-collapseTwelve',
        answer:'Indigena is a group comprised of distinctive Indigenous backgrounds from across the globe coming together as one.Made by indigenous for indigenous people.'
    },
    
]

export default FAQHeadings