import NFTImage1 from '../../Assets/NFT-0.png'
import NFTImage2 from '../../Assets/NFT-1.png'
import NFTImage3 from '../../Assets/NFT-2.png'
import NFTImage4 from '../../Assets/NFT-3.png'
import NFTImage5 from '../../Assets/NFT-4.png'
import NFTImage6 from '../../Assets/NFT-5.png'
import NFTImage7 from '../../Assets/NFT-6.png'
import NFTImage8 from '../../Assets/NFT-7.png'
import NFTImage9 from '../../Assets/NFT-8.png'
import NFTImage10 from '../../Assets/NFT-9.png'
import NFTImage11 from '../../Assets/NFT-5.png'
import NFTImage12 from '../../Assets/NFT-1.png'


let NFTCardData = [
    {
        nftImage:NFTImage1,
        price:'3.12'
    },
    {
        nftImage:NFTImage2,
        price:'4.08'
    },
    {
        nftImage:NFTImage3,
        price:'9.02'
    },
    {
        nftImage:NFTImage4,
        price:'3.12'
    },
    {
        nftImage:NFTImage5,
        price:'3.12'
    },
    {
        nftImage:NFTImage6,
        price:'7.09'
    },
    {
        nftImage:NFTImage7,
        price:'3.12'
    },
    {
        nftImage:NFTImage8,
        price:'2.79'
    },
    {
        nftImage:NFTImage9,
        price:'3.12'
    },
    {
        nftImage:NFTImage10,
        price:'4.76'
    },
    {
        nftImage:NFTImage11,
        price:'4.20'
    },
    {
        nftImage:NFTImage12,
        price:'3.12'
    },
]

export default NFTCardData