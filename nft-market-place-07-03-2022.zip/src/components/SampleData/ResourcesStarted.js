import resourceImage1 from '../../Assets/resource-card-1.png'
import resourceImage2 from '../../Assets/resource-card-2.png'
import resourceImage3 from '../../Assets/resource-card-3.png'

let resourceCardData = [ 
    {
        image:resourceImage1
    },
    {
        image:resourceImage2
    },
    {
        image:resourceImage3
    },
]

export default resourceCardData