import collectionImage1 from '../../Assets/rectangle.png'
import collectionImage2 from '../../Assets/rectangle-11.png'
import collectionImage3 from '../../Assets/rectangle-1.png'
import collectionImage4 from '../../Assets/rectangle-2.png'
import collectionImage5 from '../../Assets/rectangle-11.png'
import collectionImage6 from '../../Assets/Ellipse-1-copy-7.png'



let TopCollectionsList = [
    {
        collectionName:'Kai',
        desc:'Kai represents the current Indigena Team',
        collectionImage:collectionImage1,
    },
    {
        collectionName:'Kai',
        desc:'Enter the sandbox and become neighbour of Johnny Doe',
        collectionImage:collectionImage2,
    },
    {
        collectionName:'Arrente',
        desc:'Enter the sandbox and become neighbour of Johnny Doe',
        collectionImage:collectionImage3,
    },
    {
        collectionName:'Johnny Doe',
        desc:'Enter the sandbox and become neighbour of Johnny Doe',
        collectionImage:collectionImage4,
    },
    {
        collectionName:'Kai',
        desc:'Enter the sandbox and become neighbour of Johnny Doe',
        collectionImage:collectionImage5,
    },
    {
        collectionName:'Johnny Doe',
        desc:'Enter the sandbox and become neighbour of Johnny Doe',
        collectionImage:collectionImage4,
    },
    
  
]

export default TopCollectionsList