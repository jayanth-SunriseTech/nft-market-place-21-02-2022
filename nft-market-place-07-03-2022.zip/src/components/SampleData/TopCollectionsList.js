import userProfile1 from '../../Assets/list-profile.png'
import userProfile2 from '../../Assets/Ellipse-1-copy-3.png'
import userProfile3 from '../../Assets/Ellipse-1-copy-4.png'
import userProfile4 from '../../Assets/Ellipse-1-copy-5.png'
import userProfile5 from '../../Assets/Ellipse-1-copy-6.png'
import userProfile6 from '../../Assets/Ellipse-1-copy-7.png'
import userProfile7 from '../../Assets/Ellipse-1-copy-8.png'
import userProfile8 from '../../Assets/list-profile-9.png'
import userProfile9 from '../../Assets/list-profile-8.png'
import userProfile10 from '../../Assets/list-profile-7.png'
import userProfile11 from '../../Assets/list-profile-5.png'
import userProfile12 from '../../Assets/list-profile-2.png'
import userProfile13 from '../../Assets/list-profile-3.png'
import userProfile14 from '../../Assets/profile-list.png'
import userProfile15 from '../../Assets/profile-list.png'


let TopCollectionsList = [
    {
        collectionName:'Pixel Art',
        userName:'@JohnnyCreates',
        profileImage:userProfile1,
        rating:'93.57'
    },
    {
        collectionName:'Pixel Art',
        userName:'@JohnnyCreates',
        profileImage:userProfile2,
        rating:'93.57'
    },
    {
        collectionName:'Pixel Art',
        userName:'@JohnnyCreates',
        profileImage:userProfile3,
        rating:'93.57'
    },
    {
        collectionName:'Pixel Art',
        userName:'@JohnnyCreates',
        profileImage:userProfile4,
        rating:'93.57'
    },
    {
        collectionName:'Pixel Art',
        userName:'@JohnnyCreates',
        profileImage:userProfile5,
        rating:'93.57'
    },
    {
        collectionName:'Pixel Art',
        userName:'@JohnnyCreates',
        profileImage:userProfile6,
        rating:'93.57'
    },
    {
        collectionName:'Pixel Art',
        userName:'@JohnnyCreates',
        profileImage:userProfile7,
        rating:'93.57'
    },
    {
        collectionName:'Pixel Art',
        userName:'@JohnnyCreates',
        profileImage:userProfile8,
        rating:'93.57'
    },
    {
        collectionName:'Pixel Art',
        userName:'@JohnnyCreates',
        profileImage:userProfile9,
        rating:'93.57'
    },
    {
        collectionName:'Pixel Art',
        userName:'@JohnnyCreates',
        profileImage:userProfile10,
        rating:'93.57'
    },
    {
        collectionName:'Pixel Art',
        userName:'@JohnnyCreates',
        profileImage:userProfile11,
        rating:'93.57'
    },
    {
        collectionName:'Pixel Art',
        userName:'@JohnnyCreates',
        profileImage:userProfile12,
        rating:'93.57'
    },
    {
        collectionName:'Pixel Art',
        userName:'@JohnnyCreates',
        profileImage:userProfile13,
        rating:'93.57'
    },
    {
        collectionName:'Pixel Art',
        userName:'@JohnnyCreates',
        profileImage:userProfile14,
        rating:'93.57'
    },
    {
        collectionName:'Pixel Art',
        userName:'@JohnnyCreates',
        profileImage:userProfile15,
        rating:'93.57'
    },
  
]

export default TopCollectionsList